#include <stdio.h>
#include <stdint.h>
#include "../baseline/6502cpu.c"
#undef current_instruction
#undef cycles
static uint64_t hash_memory(void) {
 uint64_t h = UINT64_C(14695981039346656037);
 for (unsigned i=0;i<65536;i++) { h ^= memory[i]; h *= UINT64_C(1099511628211); }
 return h;
}
int main(int argc,char **argv) {
 if(argc!=2 || !memory_test() || !cpu_test()) return 1;
 FILE *f=fopen(argv[1],"rb"); if(!f)return 2;
 unsigned address=0xD000; int byte;
 while(address<65536 && (byte=fgetc(f))!=EOF) memory[address++]=(BYTE)byte;
 fclose(f); store_word(0xFFFC,0xD000); cpu_reset();
 for(unsigned i=0;i<=1000000;i++){
  if(i%1000==0)printf("%u %02X %02X %02X %02X %02X %04X %02X %llu %u %016llX\n",
   i,cpu.A,cpu.X,cpu.Y,cpu.SP,cpu.P,cpu.PC,cpu.current_instruction,cpu.cycles,
   stack_depth,(unsigned long long)hash_memory());
  if(i<1000000 && !tick())return 3;
 }
 return 0;
}
