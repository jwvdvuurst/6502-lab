#ifndef CPU_6502IO_H
#define CPU_6502IO_H

#include "6502types.h"

bool clear_display(void);

bool write_string(BYTE x, BYTE y,const char* text);
bool scroll_display(BYTE l);
bool write_statmessage(const char* message);

bool display(void);
bool init_io(void);
bool close_io(void);

bool backspace_pressed(void);

bool display_test(void);

#endif // CPU_6502IO_H
