#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <curses.h>

#include "6502types.h"
#include "6502memory.h"
#include "6502cpu.h"

BYTE* displaymem = NULL;

bool  cursesmode = false;
WINDOW* disp_window = NULL;
WINDOW* stat_window = NULL;
static BYTE previous_screen[1000];
static bool screen_valid = false;


bool clear_display(void) {
    if (displaymem == NULL) return false;
    WORD address = 0;
    while ((address < 0x0400) && (displaymem[address++] = 0x20));
    return true;
}

bool write_char(BYTE x, BYTE y, const char ch ) {
    WORD charbyte = (y*40)+x;

    if (charbyte > 0x0400) return false;

    displaymem[charbyte] = ch;

    return true;
}

bool write_string(BYTE x, BYTE y,const char* text) {
    WORD startbyte = (y*40)+x;
    BYTE len = strlen(text);

    if (len == 0) return true;

    if (startbyte > 0x0400) return false;

    if (startbyte + len > 0x0400) return false;

    for(BYTE i=0; i<len; i++) displaymem[startbyte + i] = text[i];

    return true;
}

bool scroll_display(BYTE l) {
    if (l>=24) return clear_display();
    while(l>0) {
        for( WORD b=0; b<960;b++ ) displaymem[b] = displaymem[b+40];
        for( WORD b=960; b<1000; b++ ) displaymem[b] = 0x20;
        l--;
    }

    return true;
}

bool write_statmessage(const char* message) {
    bool ok = true;
    if (message == NULL || !cursesmode) return false;

    wmove(stat_window, 1, 1);
    wclrtoeol(stat_window);
    mvwprintw(stat_window,1,1,"%s",message);
    wnoutrefresh(stat_window);

    return ok;
}

bool display(void) {
    if (!cursesmode) {
        initscr();
        cbreak();
        noecho();
        keypad(stdscr,true);
        disp_window = newwin(27,42,(LINES-27)/2,(COLS-42)/2);
        box(disp_window,0,0);
        nodelay(disp_window,true);

        stat_window = newwin(5, 82, (LINES - 7),(COLS-82)/2);
        box(stat_window,0,0);


        cursesmode = true;
        screen_valid = false;
    }
        
    for(int y=0;y<25;y++) {
        for(int x=0;x<40;x++) {
            WORD address = (y*40)+x;
            if (!screen_valid || previous_screen[address] != displaymem[address]) {
                mvwaddch(disp_window,y+1,x+1,displaymem[address]);
                previous_screen[address] = displaymem[address];
            }
        }
    }

    screen_valid = true;
    wnoutrefresh(disp_window);
    doupdate();

    return true;
}

bool backspace_pressed(void) {
    if (!cursesmode) return false;

    int ch = wgetch(disp_window);

    if (ch == KEY_BACKSPACE) return true;

    return false;
}

bool init_io(void) {
    bool ok = true;
    if (displaymem == NULL) {
        displaymem = memory + 0xC000;
    }
    ok = ok && clear_display();
    ok = ok && write_string(0,0,"Ready");
    ok = ok && display();

    return ok;
}

bool close_io(void) {
    if (cursesmode) {
        delwin(disp_window);
        delwin(stat_window);
        endwin();
        cursesmode = false;
    }

    return !cursesmode;
}

bool display_test(void) {
    bool ok = true;

    ok = ok && init_io();

    int i = 0x00;
    for(int loop=0; ok && loop<100; loop++) {
        for( int x=0; ok && x<40; x++ ) {
            for( int y=0; ok && y<25; y++ ) {
                char ch = 0x41 + (i++%26);
                ok = ok && write_char(x,y,ch);
            }
        }
        ok = ok && display();
    }

    if (!ok) {
        if (cursesmode) {
            clear_display();
            write_string(0,0,"Display test failed");
            display();
        } else {
            fprintf(stderr,"Display test failed");
        }
    } else {
        clear_display();
        write_string(0,23,"Ready");
        write_string(0,24,"Display tests succeeded");
        display();
    }

    for(BYTE l=0; l<23;l++) {
        scroll_display(1);
        display();
    }
    return ok;
}
