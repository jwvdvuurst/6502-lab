#ifndef CPU_6502CPU_H
#define CPU_6502CPU_H

#include "6502types.h" 

BYTE fetch(void);
bool execute( BYTE instruction );
bool tick(void);
void cpu_request_status(void);
bool cpu_test(void);
void cpu_reset(void);

typedef struct cpu_t {
	BYTE A;
	BYTE X;
	BYTE Y;
	BYTE SP;
	BYTE P;
	WORD PC;
	BYTE current_instruction;
	BYTE *stack;
	unsigned long long cycles;
} cpu_t;

bool cpu_init(void);
unsigned long long cpu_get_cycles(void);

#endif //CPU_6502CPU_H
