# 6502 Lab

Experimenteel vervolgproject op de bestaande 6502emulator: onderzoek naar
1 KiB-banking, coöperatieve threads, meerdere virtuele CPU's met gedeeld geheugen
en een globale tijdmachine.

**Status:** zelfstandige kopie van de actuele broncode, met geverifieerde
headless baseline en een inbouwplan. De uitbreidingen zijn nog niet geïmplementeerd.

- [Inbouwplan en ontwerpkeuzes](docs/ARCHITECTURE.md)
- [Herkomst en baselinevalidatie](docs/BASELINE.md)
- [Oorspronkelijke README](docs/UPSTREAM-README.md)
- [Kopie-manifest met SHA-256-hashes](docs/COPY-MANIFEST.json)

## Uitvoeren

Met Clang en make beschikbaar:

```sh
make headless
./6502headless.exe --self-test
./6502headless.exe --ticks 1000000 --dump-screen programs/conway_life_6502.bin
```

Op Windows zonder Clang in PATH of make:

```powershell
& 'C:\Program Files\LLVM\bin\clang.exe' -Isrc -std=c11 -Wall -Wextra -Wpedantic -O2 -g -o 6502headless.exe src/6502test.c src/6502cpu.c src/6502memory.c tools/headless_io.c
.\6502headless.exe --self-test
.\6502headless.exe --ticks 1000000 --dump-screen programs/conway_life_6502.bin
```

Op Unix heet het programma 6502headless, zonder .exe. De interactieve curses-build
heeft een passende curses-toolchain nodig; de meegeleverde pdcurses.a is voor
MinGW. Die interactieve build is in deze kopie nog niet opnieuw geverifieerd.

De tick-eenheid is één instructie. De bestaande cyclustelling is niet nauwkeurig
genoeg om MHz- of hardwaretimingclaims op te baseren.

## Herkomst

Overgenomen uit de actuele lokale werkboom van 6502emulator, inclusief
niet-gecommitte bronwijzigingen. De oude .git-directory en oude uitvoerbare
bestanden/object-/debugbestanden zijn niet meegenomen. De oorspronkelijke
LICENSE en de benodigde pdcurses-bibliotheek zijn behouden.

